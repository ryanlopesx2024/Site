import React from 'react';
import { motion } from 'framer-motion';
import Typewriter from 'typewriter-effect';
import { useSpring, animated } from '@react-spring/web';
import { Sparkles } from 'lucide-react';

export default function Hero() {
  const animation = useSpring({
    from: { transform: 'translateZ(-50px)', opacity: 0 },
    to: { transform: 'translateZ(0)', opacity: 1 },
    config: { tension: 100, friction: 10 },
  });

  return (
    <div className="h-screen flex flex-col items-center justify-center relative overflow-hidden perspective">
      <div className="absolute inset-0">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/30 via-gray-900/50 to-purple-900/30 z-0" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,0,255,0.1)_0%,transparent_100%)] animate-pulse" />
      </div>
      
      <animated.div style={animation} className="text-center z-10 transform-gpu preserve-3d">
        <motion.div
          initial={{ y: 50 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
            className="absolute -top-16 left-1/2 -translate-x-1/2"
          >
            <Sparkles className="w-12 h-12 text-blue-400/70" />
          </motion.div>
          
          <h1 className="text-6xl font-black mb-4 tracking-tight leading-none">
            <span className="block text-gradient animate-gradient">
              <Typewriter
                options={{
                  strings: ['Ryan Lopes', 'Chaves Aguiar'],
                  autoStart: true,
                  loop: true,
                  delay: 75,
                  deleteSpeed: 50,
                }}
              />
            </span>
          </h1>
          <p className="text-2xl font-light text-blue-300 mb-6 tracking-wide">
            Analista de Inteligência Artificial
          </p>
          <div className="w-24 h-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500 mx-auto rounded-full animate-gradient" />
        </motion.div>
      </animated.div>
    </div>
  );
}