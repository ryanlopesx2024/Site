import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone } from 'lucide-react';

export default function Contact() {
  return (
    <motion.section 
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="py-24 relative"
    >
      <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-800 to-gray-900 opacity-50" />
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-3xl font-bold mb-12 text-center text-blue-400 tracking-tight">Contato</h2>
        <div className="max-w-xl mx-auto glass-effect p-8 rounded-2xl">
          <div className="flex flex-col items-center gap-6">
            <motion.a 
              whileHover={{ scale: 1.05 }}
              href="mailto:ryanlopesnegocios@gmail.com" 
              className="flex items-center gap-3 text-lg hover:text-blue-400 transition-colors group"
            >
              <div className="p-3 bg-blue-500/10 rounded-full group-hover:bg-blue-500/20 transition-colors">
                <Mail className="w-6 h-6" />
              </div>
              ryanlopesnegocios@gmail.com
            </motion.a>
            <motion.a 
              whileHover={{ scale: 1.05 }}
              href="https://wa.me/5527996233446" 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex items-center gap-3 text-lg hover:text-blue-400 transition-colors group"
            >
              <div className="p-3 bg-blue-500/10 rounded-full group-hover:bg-blue-500/20 transition-colors">
                <Phone className="w-6 h-6" />
              </div>
              (27) 99623-3446
            </motion.a>
          </div>
        </div>
      </div>
    </motion.section>
  );
}