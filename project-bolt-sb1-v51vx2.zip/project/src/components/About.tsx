import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles } from 'lucide-react';

export default function About() {
  return (
    <motion.section 
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="py-24 relative overflow-hidden"
    >
      <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 opacity-50" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto">
          <div className="flex items-center justify-center mb-10">
            <Sparkles className="w-8 h-8 text-blue-400 mr-3" />
            <h2 className="text-3xl font-bold text-blue-400 tracking-tight">Sobre Mim</h2>
          </div>
          <div className="glass-effect p-8 rounded-2xl">
            <p className="text-lg leading-relaxed mb-6 text-gray-300">
              Olá! Sou Ryan Lopes, 20 anos, nascido em Vitória-ES. Como analista de inteligência artificial,
              sou um entusiasta e programador focado em inovação e tecnologias de ponta.
            </p>
            <p className="text-lg leading-relaxed text-gray-300">
              Minha paixão está em criar soluções inovadoras usando IA, sempre buscando estar à frente
              das últimas tendências tecnológicas para entregar resultados excepcionais.
            </p>
          </div>
        </div>
      </div>
    </motion.section>
  );
}