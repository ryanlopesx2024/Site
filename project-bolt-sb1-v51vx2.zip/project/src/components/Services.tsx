import React from 'react';
import { motion } from 'framer-motion';
import { Bot, Database, Zap } from 'lucide-react';
import { useSpring, animated } from '@react-spring/web';

function ServiceCard({ icon, title, description }: { icon: React.ReactNode, title: string, description: string }) {
  const [spring, set] = useSpring(() => ({
    transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)',
    config: { mass: 5, tension: 350, friction: 40 },
  }));

  const calc = (x: number, y: number, rect: DOMRect) => [
    -(y - rect.top - rect.height / 2) / 20,
    (x - rect.left - rect.width / 2) / 20,
    1.05,
  ];

  const trans = (x: number, y: number, s: number) =>
    `perspective(1000px) rotateX(${x}deg) rotateY(${y}deg) scale(${s})`;

  return (
    <animated.div
      style={spring}
      onMouseMove={(e) => {
        const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
        set({ transform: trans(...calc(e.clientX, e.clientY, rect)) });
      }}
      onMouseLeave={() => set({ transform: trans(0, 0, 1) })}
      className="glass-effect p-6 rounded-2xl shadow-2xl transform-gpu"
    >
      <motion.div 
        className="mb-4 transform-gpu"
        animate={{ rotate: [0, 5, -5, 0] }}
        transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
      >
        {icon}
      </motion.div>
      <h3 className="text-2xl font-bold mb-3 text-gradient">{title}</h3>
      <p className="text-base text-gray-300 leading-relaxed">{description}</p>
    </animated.div>
  );
}

export default function Services() {
  return (
    <motion.section 
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
      className="py-24 relative"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/10 to-purple-900/10" />
      <div className="container mx-auto px-4 relative z-10">
        <h2 className="text-4xl font-black mb-12 text-center text-gradient">Serviços</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <ServiceCard 
            icon={<Bot className="w-12 h-12 text-blue-400" />}
            title="Chatbots Avançados"
            description="Desenvolvimento de chatbots personalizados usando Nicochat, Dify e Chatvolt para atendimento inteligente e automatizado."
          />
          <ServiceCard 
            icon={<Database className="w-12 h-12 text-blue-400" />}
            title="LLMs Personalizados"
            description="Criação de modelos LLM próprios usando TensorFlow e Ollama, adaptados às necessidades específicas do seu negócio."
          />
          <ServiceCard 
            icon={<Zap className="w-12 h-12 text-blue-400" />}
            title="Automação"
            description="Soluções de automação empresarial com Make, Zapier e n8n, otimizando processos e aumentando a produtividade."
          />
        </div>
      </div>
    </motion.section>
  );
}